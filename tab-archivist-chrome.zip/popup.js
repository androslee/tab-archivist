(async () => {
  const $ = id => document.getElementById(id);
  const msg = m => browser.runtime.sendMessage(m);
  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  const ok = /^https?:/.test(tab.url || '');
  const h = ok ? new URL(tab.url).hostname.replace(/^www\./, '') : '';
  $('t').textContent = tab.title || tab.url;

  const draw = async () => {
    const s = ok ? await msg({ cmd: 'status', url: tab.url }) : {};
    $('pg').textContent = s.page ? 'Starred page (click to remove)' : 'Star this page: never archive it';
    $('st').textContent = s.site ? `Starred site ${h} (click to remove)` : `Star the whole site: ${h}`;
  };
  const archive = async cat => {
    const r = await msg({ cmd: 'archiveTabs', ids: [tab.id], cats: { [tab.id]: cat } });
    $('msg').textContent = r && r.dupes ? 'Already in the archive, tab closed.' : `Archived to ${cat}.`;
    setTimeout(() => window.close(), 1100);
  };

  if (ok) {
    const { suggested, categories } = await msg({ cmd: 'suggest', url: tab.url, title: tab.title });
    const rest = [...new Set([...categories, 'Uncategorized'])].filter(c => c !== suggested)
      .sort((a, b) => a === 'Uncategorized' ? 1 : b === 'Uncategorized' ? -1 : a.localeCompare(b));
    [suggested, ...rest].forEach((c, i) => {
      const b = document.createElement('button');
      b.textContent = c; if (i === 0) { b.className = 'sug'; b.title = 'Suggested'; }
      b.onclick = () => archive(c);
      $('cats').append(b);
    });
    const add = () => { const v = $('nn').value.trim(); if (v) archive(v); };
    $('na').onclick = add;
    $('nn').onkeydown = e => { if (e.key === 'Enter') add(); };
  } else {
    $('cats').textContent = 'This page type cannot be archived.';
  }
  ['pg', 'st', 'cl', 'na'].forEach(id => $(id).disabled = !ok);
  $('pg').onclick = async () => { await msg({ cmd: 'toggleProtect', scope: 'url', url: tab.url }); draw(); };
  $('st').onclick = async () => { await msg({ cmd: 'toggleProtect', scope: 'site', url: tab.url }); draw(); };
  $('cl').onclick = async () => { await msg({ cmd: 'closeTabs', ids: [tab.id] }); window.close(); };
  $('op').onclick = () => { browser.tabs.create({ url: browser.runtime.getURL('archive.html') }); window.close(); };
  draw();
})();
