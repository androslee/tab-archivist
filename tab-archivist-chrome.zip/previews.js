// Tiny IndexedDB store for page preview images (saved on disk in the Firefox profile).
const PV = (() => {
  let dbp;
  const db = () => dbp || (dbp = new Promise((res, rej) => {
    const r = indexedDB.open('ta-previews', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('p', { keyPath: 'key' });
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  }));
  const tx = async (mode, fn) => {
    const d = await db();
    return new Promise((res, rej) => {
      const t = d.transaction('p', mode); const out = fn(t.objectStore('p'));
      t.oncomplete = () => res(out && 'result' in out ? out.result : undefined); t.onerror = () => rej(t.error);
    });
  };
  return {
    put: (key, blob) => tx('readwrite', s => { s.put({ key, blob, ts: Date.now() }); }),
    get: key => tx('readonly', s => s.get(key)),
    del: keys => tx('readwrite', s => { keys.forEach(k => s.delete(k)); }),
    async prune(keep, before) {
      const d = await db();
      return new Promise(res => {
        const t = d.transaction('p', 'readwrite'); let n = 0;
        t.objectStore('p').openCursor().onsuccess = e => {
          const c = e.target.result; if (!c) return;
          if (!keep.has(c.value.key) && c.value.ts < before) { c.delete(); n++; }
          c.continue();
        };
        t.oncomplete = () => res(n);
      });
    }
  };
})();
