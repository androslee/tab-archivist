'use strict';
globalThis.browser = globalThis.browser || globalThis.chrome;
importScripts('previews.js');
const DAY = 864e5, HOUR = 36e5;
const DEFAULTS = { archiveDays: 14, discardHours: 24, autoArchive: true, autoDiscard: true, intercept: true, maxPerSweep: 200, previews: true, skipNsfwPreviews: false };
const DEFAULT_RULES = {
  NSFW: { domains: ['pornhub.com', 'xvideos.com', 'xhamster.com', 'xnxx.com', 'redtube.com', 'youporn.com', 'rule34.xxx', 'e-hentai.org', 'nhentai.net', 'onlyfans.com', 'fansly.com'], keywords: ['porn', 'xxx', 'nsfw', 'hentai', 'onlyfans'] },
  Money: { domains: ['paypal.com', 'chase.com', 'bankofamerica.com', 'wellsfargo.com', 'fidelity.com', 'schwab.com', 'vanguard.com', 'robinhood.com', 'coinbase.com', 'binance.com', 'venmo.com', 'ynab.com', 'tradingview.com', 'finance.yahoo.com', 'investopedia.com', 'bloomberg.com', 'nerdwallet.com', 'irs.gov'], keywords: ['stock', 'stocks', 'invest', 'investing', 'crypto', 'bitcoin', 'budget', 'mortgage', '401k', 'brokerage', 'etf', 'bank'] },
  Coding: { domains: ['github.com', 'gitlab.com', 'stackoverflow.com', 'stackexchange.com', 'developer.mozilla.org', 'docs.rs', 'crates.io', 'npmjs.com', 'pypi.org', 'go.dev', 'rust-lang.org', 'docker.com', 'dev.to', 'codepen.io', 'localhost'], keywords: ['github', 'javascript', 'python', 'rust', 'golang', 'typescript', 'programming', 'api reference', 'compiler', 'docs'] },
  Shopping: { domains: ['amazon.com', 'ebay.com', 'etsy.com', 'walmart.com', 'aliexpress.com', 'newegg.com', 'bestbuy.com', 'target.com', 'costco.com', 'temu.com', 'homedepot.com'], keywords: ['cart', 'checkout', 'coupon', 'deal', 'deals'] },
  Social: { domains: ['reddit.com', 'twitter.com', 'x.com', 'facebook.com', 'instagram.com', 'linkedin.com', 'bsky.app', 'mastodon.social', 'discord.com', 'tumblr.com', 'pinterest.com'], keywords: [] },
  Media: { domains: ['youtube.com', 'youtu.be', 'twitch.tv', 'netflix.com', 'vimeo.com', 'spotify.com', 'hulu.com', 'soundcloud.com', 'imdb.com'], keywords: [] },
  Reading: { domains: ['wikipedia.org', 'medium.com', 'substack.com', 'news.ycombinator.com', 'arstechnica.com', 'theverge.com', 'nytimes.com', 'bbc.com', 'theguardian.com', 'wired.com', 'reuters.com'], keywords: ['blog', 'article', 'news', 'essay'] },
  Gaming: { domains: ['steampowered.com', 'gog.com', 'ign.com', 'pcgamer.com', 'itch.io', 'nexusmods.com'], keywords: ['game', 'games', 'gaming'] }
};
const KEYMAP = { settings: 'settings', archive: 'archive', protectedList: 'protected', rules: 'rules', overrides: 'overrides', reports: 'reports', meta: 'meta' };

let state = null, loading = null, chain = Promise.resolve();
const allowOnce = new Map();
const jobTabs = new Set();   // tabs opened by a preview job; never intercepted

const persist = (...names) => { const o = {}; for (const n of names) o[KEYMAP[n]] = state[n]; return browser.storage.local.set(o); };
function locked(fn) { const p = chain.then(fn); chain = p.catch(() => {}); return p; }
function load() {
  return loading || (loading = (async () => {
    const d = await browser.storage.local.get(['settings', 'archive', 'protected', 'rules', 'overrides', 'reports', 'meta']);
    state = { settings: { ...DEFAULTS, ...d.settings }, archive: d.archive || {}, protectedList: d.protected || [], rules: d.rules || DEFAULT_RULES, overrides: d.overrides || {}, reports: d.reports || [], meta: d.meta || {} };
    if (!state.meta.nsfwShown) { state.settings.skipNsfwPreviews = false; state.meta.nsfwShown = true; await persist('settings', 'meta'); }
    if (!state.meta.lastReportAt) { state.meta.lastReportAt = Date.now(); await persist('meta'); }
    return state;
  })());
}

// ---------- URL helpers ----------
const TRACK = /^(utm_|fbclid$|gclid$|mc_cid$|mc_eid$|igshid$|yclid$|ref_src$|_ga$)/i;
function normalize(u) {
  try {
    const x = new URL(u);
    if (x.protocol !== 'http:' && x.protocol !== 'https:') return null;
    for (const k of [...x.searchParams.keys()]) if (TRACK.test(k)) x.searchParams.delete(k);
    x.searchParams.sort();
    return x.host.replace(/^www\./, '') + (x.pathname.replace(/\/+$/, '') || '/') + x.search;
  } catch { return null; }
}
const hostOf = u => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return ''; } };
const hostMatch = (host, d) => host === d || host.endsWith('.' + d);

// ---------- categorizing ----------
function hasWord(h, k) {
  let i = h.indexOf(k);
  while (i >= 0) {
    const a = h[i - 1], b = h[i + k.length];
    if (!(a && /[a-z0-9]/.test(a)) && !(b && /[a-z0-9]/.test(b))) return true;
    i = h.indexOf(k, i + 1);
  }
  return false;
}
function categorize(url, title) {
  const host = hostOf(url);
  const parts = host.split('.');
  for (let i = 0; i < parts.length - 1; i++) { const o = state.overrides[parts.slice(i).join('.')]; if (o) return o; }
  const hay = ((title || '') + ' ' + url).toLowerCase();
  let best = 'Uncategorized', bs = 0;
  for (const [cat, r] of Object.entries(state.rules)) {
    let s = 0;
    if ((r.domains || []).some(d => hostMatch(host, d))) s += 5;
    for (const k of r.keywords || []) if (hasWord(hay, k)) s++;
    if (s > bs) { bs = s; best = cat; }
  }
  return best;
}
function isProtected(u) {
  const k = normalize(u); if (!k) return false;
  const h = hostOf(u);
  return state.protectedList.some(p => p.type === 'url' ? p.value === k : hostMatch(h, p.value));
}
const isArchivable = t => /^https?:/.test(t.url || '') && !t.pinned && !t.active && !t.audible && !isProtected(t.url);


// ---------- previews (Chrome can only photograph the tab that is showing in its window) ----------
const BLOCKED = /just a moment|attention required|captcha|verify you are|are you (a )?(human|robot)|access denied|security check|checking your browser|bot verification|robot check/i;
const lastCap = new Map();
const captureWins = new Set();
const sleep = ms => new Promise(r => setTimeout(r, ms));
let shotChain = Promise.resolve();
// Chrome limits captureVisibleTab, so calls run one at a time with a short gap
function shot(windowId) {
  const p = shotChain.then(async () => { await sleep(700); return chrome.tabs.captureVisibleTab(windowId, { format: 'jpeg', quality: 70 }); });
  shotChain = p.catch(() => {});
  return p;
}
async function pool(items, n, fn) {
  let i = 0;
  await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => { while (i < items.length) await fn(items[i++]); }));
}
async function shrink(dataUrl) {
  const bmp = await createImageBitmap(await (await fetch(dataUrl)).blob());
  const w = Math.min(480, bmp.width), h = Math.max(1, Math.round(bmp.height * w / bmp.width));
  const c = new OffscreenCanvas(w, h);
  c.getContext('2d').drawImage(bmp, 0, 0, w, h); bmp.close();
  return c.convertToBlob({ type: 'image/jpeg', quality: 0.72 });
}
async function capture(tab, manual, entry) {
  try {
    const st = await load();
    if (!manual && !st.settings.previews) return false;
    if (!tab || tab.discarded || tab.incognito || !tab.active || !/^https?:/.test(tab.url || '')) return false;
    if (BLOCKED.test(tab.title || '')) return false;
    const k = entry ? entry.key : normalize(tab.url); if (!k) return false;
    const isNsfw = entry ? entry.category === 'NSFW' : categorize(tab.url, tab.title) === 'NSFW';
    if (st.settings.skipNsfwPreviews && isNsfw) return 'skip';
    const now = Date.now();
    if (!manual && now - (lastCap.get(tab.id) || 0) < 20000) return false;
    lastCap.set(tab.id, now);
    const data = await shot(tab.windowId);
    // keep the picture only if this tab is still the one on screen and still on the same page
    const after = await chrome.tabs.get(tab.id);
    if (!after.active || normalize(after.url) !== k || BLOCKED.test(after.title || '')) return false;
    const blob = await shrink(data); if (!blob) return false;
    await PV.put(k, blob); return true;
  } catch (e) { return false; }
}
const dropPreviews = keys => PV.del(keys).catch(() => {});
chrome.tabs.onActivated.addListener(info => {
  if (captureWins.has(info.windowId)) return;
  setTimeout(async () => { try { const t = await chrome.tabs.get(info.tabId); if (t.active && !captureWins.has(t.windowId)) capture(t); } catch (e) {} }, 2500);
});
chrome.tabs.onUpdated.addListener((id, change, tab) => {
  if (change.status === 'complete' && tab.active && !captureWins.has(tab.windowId)) setTimeout(async () => { try { const t = await chrome.tabs.get(id); if (t.active) capture(t); } catch (e) {} }, 2500);
}, { properties: ['status'] });
// ---------- archiving ----------
async function archiveTabs(tabs, why, cats = {}) {
  const st = await load();
  const keys = tabs.map(t => normalize(t.url));
  await pool(tabs.filter(t => !t.discarded), 4, t => capture(t));   // last look before the tab closes
  const sk = keys.filter(Boolean).map(k => 's:' + k);
  const snips = await browser.storage.local.get(sk);
  let added = 0, dupes = 0; const ids = [];
  tabs.forEach((t, i) => {
    const k = keys[i]; if (!k) return;
    const ex = st.archive[k];
    if (ex) { ex.seen = (ex.seen || 1) + 1; dupes++; }
    else {
      const sn = snips['s:' + k];
      st.archive[k] = { key: k, url: t.url, title: t.title || k, snippet: sn ? sn.t : '', category: cats[t.id] || categorize(t.url, t.title), manual: !!cats[t.id], archivedAt: Date.now(), lastAccessed: t.lastAccessed || 0, container: t.cookieStoreId || '', seen: 1, why };
      if (cats[t.id] && !st.rules[cats[t.id]]) st.rules[cats[t.id]] = { domains: [], keywords: [] };
      added++;
    }
    ids.push(t.id);
  });
  st.meta.dupes = (st.meta.dupes || 0) + dupes;
  await persist('archive', 'meta', 'rules');              // saved first, closed second
  await browser.storage.local.remove(sk.filter(k => snips[k]));
  for (let i = 0; i < ids.length; i += 50) { try { await browser.tabs.remove(ids.slice(i, i + 50)); } catch (e) {} }
  return { added, dupes };
}

async function sweep() {
  const st = await load(), s = st.settings, now = Date.now();
  const tabs = await browser.tabs.query({});
  const res = { archived: 0, dupes: 0, discarded: 0 };
  const gone = new Set();
  if (s.autoArchive) {
    const cutoff = now - s.archiveDays * DAY;
    const old = tabs.filter(t => isArchivable(t) && t.lastAccessed && t.lastAccessed < cutoff)
      .sort((a, b) => a.lastAccessed - b.lastAccessed).slice(0, s.maxPerSweep);
    if (old.length) { const r = await archiveTabs(old, 'auto'); res.archived = r.added; res.dupes = r.dupes; old.forEach(t => gone.add(t.id)); }
  }
  if (s.autoDiscard) {
    const cutoff = now - s.discardHours * HOUR;
    const ids = tabs.filter(t => !gone.has(t.id) && !t.discarded && !t.active && !t.pinned && !t.audible && /^https?:/.test(t.url) && t.lastAccessed && t.lastAccessed < cutoff && !isProtected(t.url)).map(t => t.id);
    for (const id of ids) { try { await browser.tabs.discard(id); } catch (e) {} }
    res.discarded = ids.length;
  }
  await PV.prune(new Set(Object.keys(st.archive)), now - 30 * DAY).catch(() => {});
  return res;
}

async function makeReport(notify) {
  const st = await load(), to = Date.now(), from = st.meta.lastReportAt;
  const items = Object.values(st.archive).filter(e => e.archivedAt >= from);
  const byCategory = {}; items.forEach(e => byCategory[e.category] = (byCategory[e.category] || 0) + 1);
  const r = { id: to, from, to, count: items.length, dupes: st.meta.dupes || 0, byCategory, keys: items.map(e => e.key) };
  st.reports.unshift(r); st.reports = st.reports.slice(0, 52);
  st.meta.lastReportAt = to; st.meta.dupes = 0;
  await persist('reports', 'meta');
  if (notify && r.count) browser.notifications.create('weekly', { type: 'basic', iconUrl: browser.runtime.getURL('icon.png'), title: 'Tab Archivist weekly report', message: `Archived ${r.count} tabs this week. Click to review and re-sort them.` });
  return r;
}
async function maybeReport() { const st = await load(); if (Date.now() - st.meta.lastReportAt >= 7 * DAY) await makeReport(true); }


// ---------- re-capturing previews for archived pages ----------
let job = { running: false, total: 0, done: 0, ok: 0, failed: 0, skipped: 0, redirected: 0, current: '' };
function waitLoaded(id, ms) {
  return new Promise(res => {
    let done = false;
    const fin = () => { if (done) return; done = true; chrome.tabs.onUpdated.removeListener(fn); clearTimeout(tm); res(); };
    const fn = (tid, ch, t) => { if (tid === id && ch.status === 'complete' && t.url && t.url !== 'about:blank') fin(); };
    const tm = setTimeout(fin, ms);
    chrome.tabs.onUpdated.addListener(fn);
    chrome.tabs.get(id).then(t => { if (t.status === 'complete' && t.url && t.url !== 'about:blank') fin(); }).catch(fin);
  });
}
async function captureEntry(winId, e) {
  let tab;
  try {
    tab = await chrome.tabs.create({ windowId: winId, url: 'about:blank', active: true });
    await allowTab(tab.id);                                // let the real page load instead of the archive screen
    await chrome.tabs.update(tab.id, { url: e.url });
    await waitLoaded(tab.id, 25000);
    await sleep(3500);
    let t = await chrome.tabs.get(tab.id);
    for (let n = 0; n < 8 && BLOCKED.test(t.title || ''); n++) { await sleep(1500); t = await chrome.tabs.get(tab.id); }
    if (!/^https?:/.test(t.url)) return 'failed';
    if (normalize(t.url) !== e.key) return 'redirected';  // the site sent us somewhere else: don't save that under this page
    if (!e.snippet) {
      const sk = 's:' + e.key, v = (await chrome.storage.local.get(sk))[sk];
      if (v && v.t) { e.snippet = v.t; job.dirty = true; chrome.storage.local.remove(sk); }
    }
    const r = await capture(t, true, e);
    return r === true ? 'ok' : r === 'skip' ? 'skipped' : 'failed';
  } catch (err) { return 'failed'; }
  finally { if (tab) chrome.tabs.remove(tab.id).catch(() => {}); }
}
async function runJob(entries) {
  const keepAlive = setInterval(() => chrome.runtime.getPlatformInfo(), 10000);   // keeps the worker awake
  const wins = []; let i = 0;
  const worker = async () => {
    const w = await chrome.windows.create({ url: 'about:blank', width: 1280, height: 800, focused: false });
    wins.push(w.id); captureWins.add(w.id);
    while (!job.cancel && i < entries.length) {
      const e = entries[i++]; job.current = e.title;
      const res = await captureEntry(w.id, e);
      job[res] = (job[res] || 0) + 1; job.done++;
      if (job.dirty && job.done % 25 === 0) { job.dirty = false; locked(() => persist('archive')); }
    }
  };
  try { await Promise.all(Array.from({ length: Math.min(2, entries.length) }, worker)); }
  catch (err) { console.error(err); }
  finally {
    clearInterval(keepAlive);
    for (const id of wins) { chrome.windows.remove(id).catch(() => {}); captureWins.delete(id); }
    if (job.dirty) { job.dirty = false; await locked(() => persist('archive')); }
    job.running = false; job.current = '';
  }
}

// ---------- showing the archived copy instead of the live page (declarativeNetRequest) ----------
let ruleChain = Promise.resolve();
const scheduleSync = () => { ruleChain = ruleChain.then(syncRules).catch(() => {}); return ruleChain; };
async function syncRules() {
  const st = await load();
  const entries = st.settings.intercept
    ? Object.values(st.archive).filter(e => e.key && !/[*|^"]/.test(e.key)).slice(0, 4900)
    : [];
  const addRules = entries.map((e, i) => ({
    id: i + 1, priority: 1,
    action: { type: 'redirect', redirect: { extensionPath: '/hit.html?k=' + encodeURIComponent(e.key) } },
    condition: { urlFilter: '||' + e.key + '^', resourceTypes: ['main_frame'] }
  }));
  const old = (await chrome.declarativeNetRequest.getDynamicRules()).map(r => r.id);
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: old, addRules });
}
let allowSeq = 0;
// Let one tab load an archived page live, for about a minute.
async function allowTab(tabId) {
  const id = 900000 + (++allowSeq % 90000);
  await chrome.declarativeNetRequest.updateSessionRules({
    removeRuleIds: [id],
    addRules: [{ id, priority: 2, action: { type: 'allow' }, condition: { tabIds: [tabId], resourceTypes: ['main_frame'] } }]
  });
  setTimeout(() => chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [id] }).catch(() => {}), 60000);
}

async function openEntries(keys, remove) {
  const st = await load(); let first = true;
  for (const k of keys) {
    const e = st.archive[k]; if (!e) continue;
    const tab = await chrome.tabs.create({ url: 'about:blank', active: first });
    first = false;
    await allowTab(tab.id);
    await chrome.tabs.update(tab.id, { url: e.url });
    if (remove) { delete st.archive[k]; dropPreviews([k]); }
  }
  if (remove) await persist('archive');
}

// ---------- messages from the UI pages ----------
const MUTATING = new Set(['archiveTabs', 'delete', 'open', 'allow', 'saveSettings', 'sweep', 'closeTabs', 'clearPreview']);
async function handle(m, sender) {
  switch (m.cmd) {
    case 'snippet': { const k = normalize(m.url); if (k && m.text) await browser.storage.local.set({ ['s:' + k]: { t: m.text, ts: Date.now() } }); return; }
    case 'state': return load().then(st => ({ archive: Object.values(st.archive), settings: st.settings, protectedList: st.protectedList, rules: st.rules, reports: st.reports, categories: Object.keys(st.rules) }));
    case 'get': return load().then(st => st.archive[m.key] || null);
    case 'status': return load().then(st => ({ page: st.protectedList.some(p => p.type === 'url' && p.value === normalize(m.url)), site: st.protectedList.some(p => p.type === 'site' && p.value === hostOf(m.url)) }));
    case 'suggest': return load().then(st => ({ suggested: categorize(m.url, m.title), categories: Object.keys(st.rules) }));
    case 'toggleProtect': return locked(async () => {
      const st = await load(), val = m.scope === 'url' ? normalize(m.url) : hostOf(m.url); if (!val) return;
      const i = st.protectedList.findIndex(p => p.type === m.scope && p.value === val);
      if (i >= 0) st.protectedList.splice(i, 1); else st.protectedList.push({ type: m.scope, value: val, added: Date.now() });
      await persist('protectedList');
    });
    case 'unprotect': return locked(async () => { const st = await load(); st.protectedList.splice(m.index, 1); await persist('protectedList'); });
    case 'protectTab': return locked(async () => {
      const st = await load(), k = normalize(m.url); if (!k) return;
      if (!st.protectedList.some(p => p.type === 'url' && p.value === k)) st.protectedList.push({ type: 'url', value: k, added: Date.now() });
      await persist('protectedList');
    });
    case 'idle': return load().then(async st => {
      const now = Date.now(), cutoff = now - m.days * DAY, tabs = await browser.tabs.query({});
      return tabs.filter(t => isArchivable(t) && t.lastAccessed && t.lastAccessed < cutoff).sort((a, b) => a.lastAccessed - b.lastAccessed)
        .map(t => ({ id: t.id, url: t.url, title: t.title, idle: Math.floor((now - t.lastAccessed) / DAY), category: categorize(t.url, t.title), dup: !!st.archive[normalize(t.url)] }));
    });
    case 'archiveTabs': return locked(async () => {
      await load(); const set = new Set(m.ids);
      const tabs = (await browser.tabs.query({})).filter(t => set.has(t.id) && normalize(t.url));
      return archiveTabs(tabs, 'manual', m.cats || {});
    });
    case 'closeTabs': return browser.tabs.remove(m.ids).catch(() => {});
    case 'move': return locked(async () => {
      const st = await load(), e = st.archive[m.key]; if (!e) return;
      if (!st.rules[m.category]) st.rules[m.category] = { domains: [], keywords: [] };
      e.category = m.category; e.manual = m.manual !== false;
      if (m.learn) {
        const h = hostOf(e.url); st.overrides[h] = m.category;
        for (const x of Object.values(st.archive)) if (!x.manual && hostOf(x.url) === h) x.category = m.category;
      }
      await persist('archive', 'overrides', 'rules');
    });
    case 'delete': return locked(async () => { const st = await load(); m.keys.forEach(k => delete st.archive[k]); dropPreviews(m.keys); await persist('archive'); });
    case 'open': return locked(() => openEntries(m.keys, m.remove));
    case 'allow': return locked(async () => {
      const st = await load();
      if (m.remove && st.archive[m.key]) { delete st.archive[m.key]; dropPreviews([m.key]); await persist('archive'); }
      if (sender && sender.tab) await allowTab(sender.tab.id);
    });
    case 'saveSettings': return locked(async () => {
      const st = await load(), s = m.settings;
      st.settings = { ...st.settings, archiveDays: Math.max(1, +s.archiveDays || 14), discardHours: Math.max(1, +s.discardHours || 24), maxPerSweep: Math.max(10, +s.maxPerSweep || 200), autoArchive: !!s.autoArchive, autoDiscard: !!s.autoDiscard, intercept: !!s.intercept, previews: !!s.previews, skipNsfwPreviews: !!s.skipNsfwPreviews };
      await persist('settings');
    });
    case 'saveRules': return locked(async () => {
      const st = await load(), clean = {};
      for (const [c, r] of Object.entries(m.rules || {})) clean[c] = { domains: (r.domains || []).map(x => String(x).toLowerCase().trim()).filter(Boolean), keywords: (r.keywords || []).map(x => String(x).toLowerCase().trim()).filter(Boolean) };
      st.rules = clean;
      for (const e of Object.values(st.archive)) if (!e.manual) e.category = categorize(e.url, e.title);
      await persist('rules', 'archive');
    });
    case 'sweep': return locked(sweep);
    case 'report': return locked(() => makeReport(false));
    case 'clearPreview': return dropPreviews(m.keys);
    case 'captureAll': return load().then(async () => {
      // Chrome can only photograph the tab each window is showing
      const tabs = (await browser.tabs.query({})).filter(t => t.active && !t.discarded); let n = 0;
      await pool(tabs, 3, async t => { if ((await capture(t, true)) === true) n++; });
      return { captured: n, loaded: tabs.length };
    });
    case 'recapture': return load().then(async st => {
      if (job.running) return { started: false, reason: 'A preview job is already running.' };
      let entries = (m.keys || []).map(k => st.archive[k]).filter(Boolean);
      if (m.onlyMissing) { const have = await Promise.all(entries.map(e => PV.get(e.key).then(r => !!(r && r.blob)).catch(() => false))); entries = entries.filter((e, i) => !have[i]); }
      if (!entries.length) return { started: false, reason: 'Every page here already has a preview.' };
      job = { running: true, total: entries.length, done: 0, ok: 0, failed: 0, skipped: 0, redirected: 0, current: '', cancel: false, dirty: false };
      runJob(entries);
      return { started: true, total: entries.length };
    });
    case 'captureStatus': return job;
    case 'captureStop': job.cancel = true; return;
  }
}
chrome.runtime.onMessage.addListener((m, sender, sendResponse) => {
  Promise.resolve()
    .then(() => handle(m, sender))
    .then(r => { if (MUTATING.has(m.cmd)) scheduleSync(); return r; })
    .then(sendResponse, err => { console.error(err); sendResponse(undefined); });
  return true;   // answer asynchronously
});

// ---------- schedule ----------
chrome.alarms.get('sweep').then(a => { if (!a) chrome.alarms.create('sweep', { delayInMinutes: 2, periodInMinutes: 60 }); });
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'sweep') locked(async () => { await sweep(); await maybeReport(); }); });
chrome.notifications.onClicked.addListener(() => chrome.tabs.create({ url: chrome.runtime.getURL('archive.html#reports') }));
chrome.runtime.onInstalled.addListener(d => { if (d.reason === 'install') chrome.tabs.create({ url: chrome.runtime.getURL('archive.html#idle') }); });

// start-up: clear leftover one-off allow rules from a previous session, then rebuild the archive redirects
chrome.declarativeNetRequest.getSessionRules().then(rules => {
  const ids = rules.map(r => r.id).filter(id => id >= 900000);
  return chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: ids });
}).catch(() => {}).then(() => scheduleSync());
