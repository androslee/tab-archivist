globalThis.browser = globalThis.browser || globalThis.chrome;
