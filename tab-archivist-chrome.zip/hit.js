(async () => {
  const k = new URLSearchParams(location.search).get('k');
  const e = await browser.runtime.sendMessage({ cmd: 'get', key: k });
  const c = document.getElementById('card');
  const el = (tag, text, cls) => { const x = document.createElement(tag); if (text) x.textContent = text; if (cls) x.className = cls; return x; };
  if (!e) { c.append(el('p', 'This page is no longer in the archive.')); return; }
  document.title = 'Archived: ' + e.title;
  c.append(el('h2', e.title), el('div', `${e.url}`, 'u'), el('div', `Saved ${new Date(e.archivedAt).toLocaleDateString()} in ${e.category}`, 'u'));
  try {
    const p = await PV.get(k);
    if (p && p.blob) { const img = document.createElement('img'); img.src = URL.createObjectURL(p.blob); img.alt = ''; img.style.cssText = 'width:100%;border-radius:8px;margin:14px 0 0'; c.append(img); }
  } catch (err) {}
  if (e.snippet) c.append(el('div', e.snippet, 'snip'));
  const acts = el('div', '', 'acts');
  const go = remove => async () => { await browser.runtime.sendMessage({ cmd: 'allow', key: k, remove }); location.replace(e.url); };
  const b1 = el('button', 'Load the live page', 'primary'); b1.onclick = go(false);
  const b2 = el('button', 'Load it and remove from archive'); b2.onclick = go(true);
  const b3 = el('button', 'Open archive'); b3.onclick = () => location.replace(browser.runtime.getURL('archive.html'));
  acts.append(b1, b2, b3); c.append(acts);
})();
