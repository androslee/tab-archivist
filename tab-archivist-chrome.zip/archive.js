'use strict';
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const send = m => browser.runtime.sendMessage(m);
const fmt = t => new Date(t).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
const when = t => t ? fmt(t) : 'unknown';
const host = u => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return ''; } };
const hue = s => { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
const ls = { get: k => { try { return localStorage.getItem(k); } catch { return null; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch {} } };

let S, query = '', idleDays = 3, idleList = [], sel = new Set();
let view = ls.get('view') || 'grid', cat = null, sortBy = 'archived', shown = [], pos = 0;
let tile = +ls.get('tile') || 260, shape = ls.get('shape') || 'std';
const AR = { wide: '16/10', std: '4/3', square: '1/1', tall: '3/4' };
const BATCH = 60;
let classifying = null, busy = false;

const lazy = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { lazy.unobserve(e.target); loadPv(e.target); } }), { rootMargin: '600px' });
const more = new IntersectionObserver(es => { if (es.some(e => e.isIntersecting)) loadMore(); }, { rootMargin: '800px' });

async function loadPv(el) {
  if (el.querySelector('img')) return;
  try {
    const r = await PV.get(el.dataset.pk);
    if (r && r.blob) { const img = new Image(); img.alt = ''; img.onload = () => el.classList.add('has'); img.src = URL.createObjectURL(r.blob); el.prepend(img); }
  } catch {}
}

async function refresh() { S = await send({ cmd: 'state' }); render(); }
function render() {
  more.disconnect(); $('#main').classList.remove('wide');
  const v = (location.hash || '#archive').slice(1);
  document.querySelectorAll('nav a').forEach(a => a.classList.toggle('on', a.hash === '#' + v));
  $('#stats').textContent = `${S.archive.length} archived`;
  ({ archive: vArchive, idle: vIdle, reports: vReports, settings: vSettings }[v] || vArchive)();
}
window.addEventListener('hashchange', () => S && render());


// ---------- Archive browser ----------
const catOptions = cur => [...new Set(['Uncategorized', ...S.categories, cur])].map(c => `<option ${c === cur ? 'selected' : ''}>${esc(c)}</option>`).join('') + '<option value="__new">New category…</option>';
const meta = e => `last visited ${when(e.lastAccessed)}, archived ${fmt(e.archivedAt)}${e.seen > 1 ? `, seen ${e.seen} times` : ''}`;
const actions = e => `<select data-act="move" aria-label="Category">${catOptions(e.category)}</select><button data-act="open">Open</button><button data-act="restore">Restore</button><button data-act="repv">Update preview</button><button data-act="clrpv">Clear preview</button><button data-act="del">Delete</button>`;
const pv = (e, grid) => `<button class="pv" data-act="open" data-pk="${esc(e.key)}" style="--h:${hue(host(e.url))}" aria-label="Open ${esc(e.title)}"><span class="ph"><b>${esc((host(e.url)[0] || '?').toUpperCase())}</b>${grid ? '' : esc(host(e.url))}</span>${grid ? `<span class="cap"><b>${esc(e.title)}</b><i>${esc(host(e.url))}</i></span>` : ''}</button>`;

const gridTile = e => `<article class="tile" data-k="${esc(e.key)}">${pv(e, true)}<button class="more" data-act="more" aria-expanded="false" aria-label="Show details">…</button><div class="cd" hidden><h3>${esc(e.title)}</h3><div class="u">${esc(meta(e))}</div><div class="u url">${esc(e.url)}</div><div class="s">${e.snippet ? esc(e.snippet) : 'No text was saved for this page.'}</div><div class="acts"><button class="hide" data-act="more" aria-expanded="true">Hide details</button>${actions(e)}</div></div></article>`;
const listItem = e => `<article class="li" data-k="${esc(e.key)}"><div class="info"><div class="t" title="${esc(e.url)}">${esc(e.title)}</div><div class="u">${esc(host(e.url))}, ${esc(meta(e))}</div>${e.snippet ? `<div class="s">${esc(e.snippet)}</div>` : ''}<div class="acts">${actions(e)}</div></div>${pv(e)}</article>`;
const textRow = e => `<div class="row" data-k="${esc(e.key)}"><div class="info"><div class="t" title="${esc(e.url)}">${esc(e.title)}</div><div class="u">${esc(host(e.url))}, ${esc(meta(e))}</div>${e.snippet ? `<div class="s">${esc(e.snippet)}</div>` : ''}</div><div class="acts">${actions(e)}</div></div>`;

function vArchive() {
  classifying = null;
  if (cat === null) cat = S.archive.some(e => e.category === 'Uncategorized') ? 'Uncategorized' : '__all';
  $('#main').classList.toggle('wide', view === 'grid');
  const sizing = view === 'text' ? '' : `<label class="sz">Size <input id="tile" type="range" min="140" max="560" step="10" value="${tile}"></label><select id="shape" aria-label="Preview shape"><option value="wide">Wide</option><option value="std">Standard</option><option value="square">Square</option><option value="tall">Tall</option></select>`;
  $('#main').innerHTML = `<div class="tools"><input id="q" type="search" placeholder="Search titles, URLs and notes" value="${esc(query)}" aria-label="Search"><select id="sort" aria-label="Sort"><option value="archived">Newest archived</option><option value="visited">Last visited</option><option value="title">Title</option></select>${sizing}<div class="seg" role="group" aria-label="View">${['grid', 'list', 'text'].map(v => `<button data-view="${v}" class="${v === view ? 'on' : ''}">${v[0].toUpperCase() + v.slice(1)}</button>`).join('')}</div></div><div id="chips" class="chips"></div><div id="pvbar" class="bar"></div><div id="items"></div><div id="sentinel" style="height:1px"></div>`;
  $('#sort').value = sortBy;
  $('#sort').onchange = e => { sortBy = e.target.value; drawItems(); };
  $('#q').oninput = e => { query = e.target.value; drawItems(); };
  if (sizing) {
    $('#tile').oninput = e => { tile = +e.target.value; ls.set('tile', tile); $('#items').style.setProperty('--tile', tile + 'px'); };
    $('#shape').value = shape;
    $('#shape').onchange = e => { shape = e.target.value; ls.set('shape', shape); $('#items').style.setProperty('--ar', AR[shape]); };
  }
  drawChips(); drawItems();
  if (!pvTimer) send({ cmd: 'captureStatus' }).then(j => { if (j.running) pvPoll(); });
}
function drawChips() {
  const counts = {}; S.archive.forEach(e => counts[e.category] = (counts[e.category] || 0) + 1);
  if (cat !== '__all' && !counts[cat]) cat = '__all';
  const cats = Object.keys(counts).sort((a, b) => a === 'Uncategorized' ? -1 : b === 'Uncategorized' ? 1 : a.localeCompare(b));
  $('#chips').innerHTML = [['__all', 'All', S.archive.length], ...cats.map(c => [c, c, counts[c]])]
    .map(([v, l, n]) => `<button class="chip ${cat === v ? 'on' : ''}" data-cat="${esc(v)}">${esc(l)}<span>${n}</span></button>`).join('');
  if (!pvTimer) pvIdle();
  if (cat === 'Uncategorized' && counts.Uncategorized) $('#chips').insertAdjacentHTML('beforeend', '<button id="cls" class="chip on">Classify one by one</button>');
}

// ---------- re-capture previews for a category ----------
let pvTimer = null;
const pvBar = html => { const b = $('#pvbar'); if (b) b.innerHTML = html; };
const catKeys = () => S.archive.filter(e => cat === '__all' || e.category === cat).map(e => e.key);
function pvIdle() {
  pvBar(`<button id="pvgo">Get previews for ${cat === '__all' ? 'everything' : esc(cat)}…</button>`);
  $('#pvgo').onclick = pvConfirm;
}
function pvConfirm() {
  pvBar(`<span>Load ${catKeys().length} pages one at a time in a separate window and save a preview of each.</span><label style="margin:0"><input id="pvmiss" type="checkbox" checked> Only pages without a preview</label><button id="pvstart" class="primary">Start</button><button id="pvno">Cancel</button>`);
  $('#pvno').onclick = pvIdle;
  $('#pvstart').onclick = async () => {
    const r = await send({ cmd: 'recapture', keys: catKeys(), onlyMissing: $('#pvmiss').checked });
    if (!r.started) { pvBar(`<span class="hint">${esc(r.reason || 'Nothing to capture.')}</span>`); setTimeout(() => { if (!pvTimer) pvIdle(); }, 3500); return; }
    pvPoll();
  };
}
function pvPoll() {
  if (pvTimer) return;
  const tick = async () => {
    const j = await send({ cmd: 'captureStatus' });
    if (!$('#pvbar')) { if (!j.running) { clearInterval(pvTimer); pvTimer = null; } return; }
    document.querySelectorAll('#items .pv:not(.has)').forEach(loadPv);
    if (j.running) {
      if (!$('#pvstop')) { pvBar('<span id="pvtxt"></span><button id="pvstop">Stop</button>'); $('#pvstop').onclick = () => send({ cmd: 'captureStop' }); }
      $('#pvtxt').textContent = `Capturing ${j.done} of ${j.total} (${j.ok} saved, ${j.failed} failed): ${j.current || ''}`;
    } else {
      clearInterval(pvTimer); pvTimer = null;
      document.querySelectorAll('#items .pv').forEach(el => { el.querySelector('img')?.remove(); el.classList.remove('has'); loadPv(el); });
      S = await send({ cmd: 'state' }); shown = shown.map(x => S.archive.find(y => y.key === x.key)).filter(Boolean);
      pvBar(`<span>Finished: ${j.ok} saved, ${j.failed} failed${j.skipped ? `, ${j.skipped} skipped` : ''}. Failures are pages that did not load or redirected elsewhere.</span><button id="pvok">OK</button>`);
      $('#pvok').onclick = pvIdle;
    }
  };
  pvTimer = setInterval(tick, 1500); tick();
}
function drawItems() {
  const q = query.trim().toLowerCase();
  const cmp = { archived: (a, b) => b.archivedAt - a.archivedAt, visited: (a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0), title: (a, b) => a.title.localeCompare(b.title) }[sortBy];
  shown = S.archive.filter(e => (cat === '__all' || e.category === cat) && (!q || (e.title + ' ' + e.url + ' ' + e.snippet).toLowerCase().includes(q))).sort(cmp);
  pos = 0; more.disconnect();
  const box = $('#items'); box.className = view; box.innerHTML = '';
  box.style.setProperty('--tile', tile + 'px'); box.style.setProperty('--ar', AR[shape]);
  if (!shown.length) { box.innerHTML = `<p class="empty">${S.archive.length ? 'Nothing matches.' : 'Nothing archived yet. Open Idle tabs to archive some now, or wait for the hourly sweep.'}</p>`; return; }
  loadMore();
}
function loadMore() {
  const box = $('#items'), end = Math.min(pos + BATCH, shown.length);
  box.insertAdjacentHTML('beforeend', shown.slice(pos, end).map({ grid: gridTile, list: listItem, text: textRow }[view]).join(''));
  box.querySelectorAll('.pv:not([data-seen])').forEach(el => { el.dataset.seen = 1; lazy.observe(el); });
  pos = end; more.disconnect();
  if (pos < shown.length) more.observe($('#sentinel'));
}
function dropFromView(k) {
  const i = shown.findIndex(x => x.key === k);
  if (i >= 0) { shown.splice(i, 1); if (i < pos) pos--; }
  $('#items [data-k="' + CSS.escape(k) + '"]')?.remove();
  if (!shown.length) $('#items').innerHTML = '<p class="empty">Nothing left here.</p>';
  drawChips();
}
function removeItem(k) { S.archive = S.archive.filter(x => x.key !== k); $('#stats').textContent = `${S.archive.length} archived`; dropFromView(k); }

// ---------- Idle tabs ----------
async function vIdle() {
  $('#main').innerHTML = `<div class="bar">Open tabs not visited in <select id="days">${[1, 3, 7, 14].map(d => `<option value="${d}" ${d === idleDays ? 'selected' : ''}>${d}+ days</option>`).join('')}</select><span id="cnt" class="n"></span><button id="selall">Select all</button><button id="go" class="primary">Archive selected</button><button id="close">Close selected without archiving</button></div><p class="hint">Archived tabs are saved first, then closed. Star (keep) a tab to exclude it for good.</p><div id="list">Loading…</div>`;
  $('#days').onchange = e => { idleDays = +e.target.value; vIdle(); };
  idleList = await send({ cmd: 'idle', days: idleDays }); sel = new Set(idleList.map(t => t.id));
  drawIdle();
  $('#selall').onclick = () => { sel = sel.size === idleList.length ? new Set() : new Set(idleList.map(t => t.id)); drawIdle(); };
  $('#close').onclick = async () => {
    if (!sel.size || !confirm(`Close ${sel.size} tabs without saving them? This cannot be undone.`)) return;
    await send({ cmd: 'closeTabs', ids: [...sel] }); vIdle();
  };
  $('#go').onclick = async () => {
    if (!sel.size) return;
    $('#go').disabled = true; $('#go').textContent = 'Archiving…';
    const cats = {}; idleList.forEach(t => { if (t.changed && sel.has(t.id)) cats[t.id] = t.category; });
    await send({ cmd: 'archiveTabs', ids: [...sel], cats }); await refresh();
  };
}
function drawIdle() {
  $('#cnt').textContent = `${idleList.length} tabs, ${sel.size} selected`;
  $('#list').innerHTML = idleList.length ? idleList.map(t => `<div class="row"><label style="display:flex;gap:10px;margin:0;min-width:0"><input type="checkbox" data-id="${t.id}" ${sel.has(t.id) ? 'checked' : ''}><span class="info"><span class="t" style="display:block" title="${esc(t.url)}">${esc(t.title)}</span><span class="u">${esc(host(t.url))}, idle ${t.idle} days${t.dup ? ', already in archive (will not be copied)' : ''}</span></span></label><div class="acts"><select data-act="idlecat" data-id="${t.id}" aria-label="Category">${catOptions(t.category)}</select><button data-act="keep" data-id="${t.id}" data-url="${esc(t.url)}">Star</button><button data-act="closetab" data-id="${t.id}">Close</button></div></div>`).join('') : '<p class="empty">No tabs idle that long.</p>';
}

// ---------- Reports ----------
function vReports() {
  const byKey = new Map(S.archive.map(e => [e.key, e]));
  $('#main').innerHTML = `<div class="bar"><button id="mk">Generate report now</button><span class="hint">A report is created automatically every 7 days.</span></div>` + (S.reports.length ? S.reports.map(r => `<details><summary>${fmt(r.from)} to ${fmt(r.to)}<span class="n">${r.count} archived${r.dupes ? `, ${r.dupes} duplicates skipped` : ''}</span></summary><div class="chips">${Object.entries(r.byCategory).map(([c, n]) => `<span class="chip">${esc(c)} ${n}</span>`).join('')}</div>${r.keys.map(k => byKey.get(k)).filter(Boolean).map(e => `<div class="mini">${esc(e.title)} <i>${esc(host(e.url))}, ${esc(e.category)}</i></div>`).join('')}</details>`).join('') : '<p class="empty">No reports yet.</p>');
  $('#mk').onclick = async () => { await send({ cmd: 'report' }); await refresh(); };
}

// ---------- Settings ----------
function vSettings() {
  const s = S.settings;
  $('#main').innerHTML = `<h2>Automation</h2>
<label><input id="autoA" type="checkbox" ${s.autoArchive ? 'checked' : ''}> Archive tabs not visited for <input id="aDays" type="number" min="1" value="${s.archiveDays}"> days</label>
<label><input id="autoD" type="checkbox" ${s.autoDiscard ? 'checked' : ''}> Unload tabs not visited for <input id="dH" type="number" min="1" value="${s.discardHours}"> hours</label>
<label><input id="icp" type="checkbox" ${s.intercept ? 'checked' : ''}> Show the archived copy when I open an archived page</label>
<label><input id="pvOn" type="checkbox" ${s.previews ? 'checked' : ''}> Save a preview image of a page when I leave it</label>
<label><input id="pvNs" type="checkbox" ${s.skipNsfwPreviews ? 'checked' : ''}> Skip previews for NSFW pages</label>
<label>Archive at most <input id="mx" type="number" min="10" value="${s.maxPerSweep}"> tabs per hourly sweep</label>
<div class="bar"><button id="saveS" class="primary">Save</button><button id="sweep">Run sweep now</button><button id="cap">Capture previews of open tabs now</button><span id="msg" class="hint"></span></div>
<h2>Starred (never archived)</h2>
${S.protectedList.length ? S.protectedList.map((p, i) => `<div class="mini">${p.type === 'site' ? 'Whole site' : 'Page'}: ${esc(p.value)} <button data-act="unprot" data-i="${i}">Remove</button></div>`).join('') : '<p class="empty">Nothing starred. Use the toolbar button on a tab to star its page or site.</p>'}
<h2>Category rules</h2><p class="hint">Each category lists domains (match subdomains too) and keywords (whole words in the title or URL).</p>
<textarea id="rules" rows="14">${esc(JSON.stringify(S.rules, null, 2))}</textarea><div class="bar"><button id="saveR">Save rules</button><span id="rmsg" class="hint"></span></div>
<h2>Data</h2><button id="exp">Export archive as JSON</button>`;
  $('#saveS').onclick = async () => {
    await send({ cmd: 'saveSettings', settings: { archiveDays: $('#aDays').value, discardHours: $('#dH').value, maxPerSweep: $('#mx').value, autoArchive: $('#autoA').checked, autoDiscard: $('#autoD').checked, intercept: $('#icp').checked, previews: $('#pvOn').checked, skipNsfwPreviews: $('#pvNs').checked } });
    $('#msg').textContent = 'Saved.';
  };
  $('#sweep').onclick = async () => { $('#msg').textContent = 'Sweeping…'; const r = await send({ cmd: 'sweep' }); $('#msg').textContent = `Archived ${r.archived}, skipped ${r.dupes} duplicates, unloaded ${r.discarded}.`; };
  $('#cap').onclick = async () => { $('#msg').textContent = 'Capturing…'; const r = await send({ cmd: 'captureAll' }); $('#msg').textContent = `Saved ${r.captured} previews from ${r.loaded} loaded tabs. Unloaded tabs can't be captured.`; };
  $('#saveR').onclick = async () => {
    try { await send({ cmd: 'saveRules', rules: JSON.parse($('#rules').value) }); $('#rmsg').textContent = 'Saved. Unsorted archive items were re-categorized.'; }
    catch (e) { $('#rmsg').textContent = 'That is not valid JSON: ' + e.message; }
  };
  $('#exp').onclick = () => {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([JSON.stringify(S.archive, null, 2)], { type: 'application/json' }));
    a.download = 'tab-archive.json'; a.click();
  };
}

// ---------- events ----------
document.addEventListener('click', async e => {
  if (e.target.closest('#cls')) return vClassify();
  if (e.target.closest('#back')) return vArchive();
  const cb = e.target.closest('[data-cat]');
  if (cb) { cat = cb.dataset.cat; drawChips(); return drawItems(); }
  const vb = e.target.closest('[data-view]');
  if (vb) { view = vb.dataset.view; ls.set('view', view); return vArchive(); }
  const b = e.target.closest('[data-act]'); if (!b || b.tagName === 'SELECT') return;
  const act = b.dataset.act, item = b.closest('[data-k]'), k = item?.dataset.k;
  if (act === 'more') {
    const d = $('.cd', item); d.hidden = !d.hidden;
    item.classList.toggle('open', !d.hidden && item.classList.contains('tile'));
    $('.more', item)?.setAttribute('aria-expanded', String(!d.hidden));
    return;
  }
  if (act === 'open') return send({ cmd: 'open', keys: [k], remove: false });
  if (act === 'repv') {
    const r = await send({ cmd: 'recapture', keys: [k], onlyMissing: false });
    if (!r.started) { pvBar(`<span class="hint">${esc(r.reason)}</span>`); setTimeout(() => { if (!pvTimer) pvIdle(); }, 3500); return; }
    window.scrollTo({ top: 0, behavior: 'smooth' }); return pvPoll();
  }
  if (act === 'clrpv') {
    await send({ cmd: 'clearPreview', keys: [k] });
    const p = $('.pv', item); p.querySelector('img')?.remove(); p.classList.remove('has'); return;
  }
  if (act === 'restore') { const t = S.archive.find(x => x.key === k)?.title || 'Page'; await send({ cmd: 'open', keys: [k], remove: true }); removeItem(k); return toast(`Opened "${short(t)}" and removed it from the archive.`); }
  if (act === 'del') {
    const ent = S.archive.find(x => x.key === k); if (!ent) return;
    await send({ cmd: 'delete', keys: [k] }); removeItem(k);
    return toast(`Deleted "${short(ent.title)}". This cannot be undone.`);
  }
  if (act === 'keep') { await send({ cmd: 'protectTab', url: b.dataset.url }); idleList = idleList.filter(t => t.id !== +b.dataset.id); sel.delete(+b.dataset.id); return drawIdle(); }
  if (act === 'closetab') { await send({ cmd: 'closeTabs', ids: [+b.dataset.id] }); idleList = idleList.filter(t => t.id !== +b.dataset.id); sel.delete(+b.dataset.id); return drawIdle(); }
  if (act === 'unprot') { await send({ cmd: 'unprotect', index: +b.dataset.i }); return refresh(); }
});
document.addEventListener('change', async e => {
  const el = e.target;
  if (el.dataset.id && el.type === 'checkbox') { el.checked ? sel.add(+el.dataset.id) : sel.delete(+el.dataset.id); $('#cnt').textContent = `${idleList.length} tabs, ${sel.size} selected`; return; }
  if (el.dataset.act === 'idlecat') {
    const t = idleList.find(x => x.id === +el.dataset.id); let c = el.value;
    if (c === '__new') { c = (prompt('New category name:') || '').trim(); if (!c) { el.value = t.category; return; } if (!S.categories.includes(c)) S.categories.push(c); }
    t.category = c; t.changed = true; return drawIdle();
  }
  if (el.dataset.act !== 'move') return;
  const k = el.closest('[data-k]').dataset.k, ent = S.archive.find(x => x.key === k);
  let c = el.value;
  if (c === '__new') { c = (prompt('New category name:') || '').trim(); if (!c) { el.value = ent.category; return; } }
  const prev = ent.category, prevManual = !!ent.manual;
  await send({ cmd: 'move', key: k, category: c });
  ent.category = c; ent.manual = true; if (!S.categories.includes(c)) S.categories.push(c);
  if (cat !== '__all') dropFromView(k); else { el.value = c; drawChips(); }
  toast(`Moved "${short(ent.title)}" to ${c}.`, async () => {
    await send({ cmd: 'move', key: k, category: prev, manual: prevManual }); await refresh();
  });
});
refresh();

// ---------- toast ----------
const short = t => t.length > 60 ? t.slice(0, 57) + '…' : t;
let toastTimer = null;
function toast(text, undo) {
  let t = document.getElementById('toast');
  if (!t) { t = document.createElement('div'); t.id = 'toast'; t.setAttribute('role', 'status'); document.body.append(t); }
  t.textContent = '';
  const span = document.createElement('span'); span.textContent = text; t.append(span);
  if (undo) {
    const b = document.createElement('button'); b.textContent = 'Undo';
    b.onclick = async () => { t.classList.remove('show'); await undo(); };
    t.append(b);
  }
  t.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), undo ? 8000 : 4500);
}

// ---------- classify one by one (Uncategorized) ----------
function vClassify() {
  const queue = S.archive.filter(e => e.category === 'Uncategorized').sort((a, b) => b.archivedAt - a.archivedAt).map(e => e.key);
  classifying = { queue, done: 0, cats: [] };
  drawClassify();
}
function drawClassify() {
  const main = $('#main'), c = classifying;
  main.classList.remove('wide');
  const k = c.queue[0], e = k && S.archive.find(x => x.key === k);
  if (!e) {
    main.innerHTML = `<div class="slide-end"><h2>All done</h2><p class="hint">${c.done} pages sorted this session.</p><button id="back" class="primary">Back to archive</button></div>`;
    return;
  }
  const counts = {}; S.archive.forEach(x => counts[x.category] = (counts[x.category] || 0) + 1);
  c.cats = [...new Set(S.categories)].filter(x => x !== 'Uncategorized')
    .sort((a, b) => (counts[b] || 0) - (counts[a] || 0) || a.localeCompare(b));
  main.innerHTML = `
    <div class="cls-top"><button id="back">Back to archive</button><span class="n">${c.queue.length} left, ${c.done} sorted</span></div>
    <div class="cls-cats" role="group" aria-label="Categories">${c.cats.map((x, i) => `<button class="cc" data-i="${i}">${i < 9 ? `<kbd>${i + 1}</kbd>` : ''}${esc(x)}<span>${counts[x] || 0}</span></button>`).join('')}</div>
    <div class="cls-new"><input id="newcat" placeholder="Or type a new category" maxlength="40" aria-label="New category name"><button id="addcat">Add and sort here</button></div>
    <div class="cls-body">
      <div class="pv cls-pv" data-pk="${esc(e.key)}" style="--h:${hue(host(e.url))}"><span class="ph"><b>${esc((host(e.url)[0] || '?').toUpperCase())}</b>${esc(host(e.url))}</span></div>
      <h2 class="cls-t">${esc(e.title)}</h2>
      <div class="u">${esc(host(e.url))}, last visited ${when(e.lastAccessed)}, archived ${fmt(e.archivedAt)}</div>
      <div class="u url">${esc(e.url)}</div>
      ${e.snippet ? `<div class="s cls-s">${esc(e.snippet)}</div>` : '<div class="u">No text was saved for this page.</div>'}
      <div class="acts"><button id="copen">Open page</button><button id="skip">Skip for now</button></div>
      <p class="hint">Press 1 to 9 to pick a category, or the right arrow key to skip.</p>
    </div>`;
  loadPv(main.querySelector('.cls-pv'));
  main.querySelectorAll('.cc').forEach(b => b.onclick = () => classifyAssign(c.cats[+b.dataset.i]));
  $('#addcat').onclick = () => { const v = $('#newcat').value.trim(); if (v) classifyAssign(v); };
  $('#newcat').onkeydown = ev => { if (ev.key === 'Enter') { const v = ev.target.value.trim(); if (v) classifyAssign(v); } };
  $('#copen').onclick = () => send({ cmd: 'open', keys: [k], remove: false });
  $('#skip').onclick = () => classifySkip();
}
async function classifyAssign(cat) {
  if (busy || !classifying || !classifying.queue.length) return;
  busy = true;
  const k = classifying.queue.shift(), ent = S.archive.find(x => x.key === k);
  try {
    await send({ cmd: 'move', key: k, category: cat });
    ent.category = cat; ent.manual = true; if (!S.categories.includes(cat)) S.categories.push(cat);
    classifying.done++;
    toast(`Sent "${short(ent.title)}" to ${cat}.`, async () => {
      await send({ cmd: 'move', key: k, category: 'Uncategorized', manual: false });
      ent.category = 'Uncategorized'; ent.manual = false;
      if (classifying) { classifying.queue.unshift(k); classifying.done--; drawClassify(); }
    });
  } finally { busy = false; }
  if (classifying) drawClassify();
}
function classifySkip() {
  if (!classifying || classifying.queue.length < 2) return;
  classifying.queue.push(classifying.queue.shift()); drawClassify();
}
document.addEventListener('keydown', ev => {
  if (!classifying || !$('.cls-body') || ev.target.matches('input, textarea')) return;
  const n = +ev.key;
  if (n >= 1 && n <= 9 && classifying.cats[n - 1]) { ev.preventDefault(); classifyAssign(classifying.cats[n - 1]); }
  else if (ev.key === 'ArrowRight') { ev.preventDefault(); classifySkip(); }
});
