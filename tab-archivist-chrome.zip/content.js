// Grabs a short text snippet once per page load so the archive can remind you why you kept it.
setTimeout(() => {
  try {
    const meta = document.querySelector('meta[name="description"],meta[property="og:description"]');
    let t = meta && meta.content ? meta.content.trim() : '';
    if (t.length < 60) t = (t + ' ' + ((document.body && document.body.innerText) || '').slice(0, 1500)).replace(/\s+/g, ' ').trim();
    if (t) chrome.runtime.sendMessage({ cmd: 'snippet', url: location.href, text: t.slice(0, 300) });
  } catch (e) {}
}, 3000);
